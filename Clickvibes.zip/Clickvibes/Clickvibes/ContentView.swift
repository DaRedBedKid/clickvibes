//
//  ContentView.swift
//  Clickvibes
//
//  Created by Eli on 2024/4/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Clickvibes v1.0.1")
                .fontWeight(.bold)
                .position(x: 175.0, y: 0)
                .font(.title)
            
            Text("Mouse sounds:")
                .font(.title2)
                .position(x: 175.0, y: -100.0)
            Text("Made with LOVE by: DaRedBedKid")
                .font(.title2)
                .foregroundColor(Color.red)
                .position(x: 175, y: 20)
        }
        .frame(width: 350.0, height: 500.0)
        .padding()
    }
}

#Preview {
    ContentView()
}
