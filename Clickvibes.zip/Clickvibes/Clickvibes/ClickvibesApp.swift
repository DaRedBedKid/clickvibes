//
//  ClickvibesApp.swift
//  Clickvibes
//
//  Created by Eli on 2024/4/22.
//

import SwiftUI

@main
struct ClickvibesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
